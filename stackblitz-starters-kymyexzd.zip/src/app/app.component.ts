// import { Component, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { InputComponent } from './main/components/input/input';
// import { NavigatorComponent } from './main/components/navigator/navigator';
// import { PermutationService } from './main/service/permutation';
// import { AllPermutationsComponent } from './main/components/all-permutations/all-permutations';

// type AppState = 'input' | 'navigate' | 'all';

// @Component({
//   selector: 'app-root',
//   standalone: true,
//   imports: [CommonModule, InputComponent, NavigatorComponent, AllPermutationsComponent],
//   templateUrl: 'app.component.html',
//   styleUrl: 'app.component.css',
// })
// export class AppComponent implements OnInit {
//   state: AppState = 'input';
//   n = 0;

//   constructor(private permService: PermutationService) {}

//   ngOnInit(): void {
//     this.permService.n$.subscribe((n) => {
//       if (n > 0 && this.state === 'input') {
//         this.state = 'navigate';
//       }
//       this.n = n;
//     });
//   }

//   onShowAll(): void {
//     this.state = 'all';
//   }

//   onBackToNavigate(): void {
//     this.state = 'navigate';
//   }

//   onReset(): void {
//     this.permService.reset();
//     this.state = 'input';
//   }
// }
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: 'app.component.html',
})
export class AppComponent {}
