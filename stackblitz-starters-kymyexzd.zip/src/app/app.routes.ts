import { Routes } from '@angular/router';
import { InputComponent } from './main/components/input/input';
import { NavigatorComponent } from './main/components/navigator/navigator';
import { AllPermutationsComponent } from './main/components/all-permutations/all-permutations';
import { permutationGuard } from './main/guards/permutation-guard';

export const routes: Routes = [
  { path: '', component: InputComponent },
  {
    path: 'navigate',
    component: NavigatorComponent,
    canActivate: [permutationGuard],
  },
  {
    path: 'results',
    component: AllPermutationsComponent,
    canActivate: [permutationGuard],
  },
  { path: '**', redirectTo: '' },
];
