export const environment = {
  production: false,
  mock: true,
  apiUrl: 'https://orange-sniffle-464w75vqj573pqw-5069.app.github.dev',
  // apiUrl: 'http://localhost:5000/api',
};
