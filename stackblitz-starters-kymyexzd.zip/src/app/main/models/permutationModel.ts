export interface StartResponse {
  n: number;
  totalCount: string;
}

export interface NextResponse {
  index: number;
  permutation: number[];
  hasMore: boolean;
}

export interface GetAllResponse {
  permutations: { index: number; values: number[] }[];
  totalCount: string;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
}