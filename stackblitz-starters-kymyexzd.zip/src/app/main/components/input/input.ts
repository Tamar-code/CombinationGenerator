import { Component, inject } from '@angular/core';
import { PermutationService } from '../../service/permutation-service';

@Component({
  selector: 'app-input',
  standalone: true,
  imports: [],
  templateUrl: './input.html',
  styleUrl: './input.css',
})
export class InputComponent {
  permService = inject(PermutationService);

  isValid(): boolean {
    const n = this.permService.inputNumber();
    return n >= 1 && n <= 20;
  }

  onStart(): void {
    if (this.isValid()) {
      this.permService.start();
    }
  }
}