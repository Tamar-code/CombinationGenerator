import { Component, inject, signal, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PaginationComponent } from '../pagination/pagination';
import { GetAllResponse } from '../../models/permutationModel';
import { PermutationService } from '../../service/permutation-service';

@Component({
  selector: 'app-all-permutations',
  standalone: true,
  imports: [PaginationComponent],
  templateUrl: './all-permutations.html',
  styleUrl: './all-permutations.css',
})
export class AllPermutationsComponent implements OnInit {
  permService = inject(PermutationService);
  router = inject(Router);

  permutations = signal<{ index: number; values: number[] }[]>([]);
  totalPages = signal<number>(0);
  currentPage = signal<number>(1);
  pageSize = 20;

  ngOnInit(): void {
    // מתחיל מהקומבינציה הבאה אחרי זו שהוצגה
    this.permService.allPermutationsCurrentIndex.set(
      this.permService.currentIndex()
    );
    this.loadPage(1);
  }

  loadPage(page: number): void {
    this.currentPage.set(page);
    this.permService.getAll(page, this.pageSize, (res: GetAllResponse) => {
      this.permutations.set(res.permutations);
      this.totalPages.set(res.totalPages);
    });
  }

  onPageChange(page: number): void {
    this.loadPage(page);
  }

  onBack(): void {
    // מעדכן את הקומבינציה הנוכחית לאחרונה שהוצגה ב-all
    const lastShown = this.permutations()[this.permutations().length - 1];
    if (lastShown) {
      this.permService.currentIndex.set(lastShown.index);
      this.permService.currentPermutation.set(lastShown.values);
    }
    this.router.navigate(['/navigate']);
  }
}