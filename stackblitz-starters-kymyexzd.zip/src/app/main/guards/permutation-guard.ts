import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { PermutationService } from '../service/permutation-service';

export const permutationGuard: CanActivateFn = () => {
  console.log('in guards ');
  const permService = inject(PermutationService);
  const router = inject(Router);

  if (permService.totalCount() !== '0') {
    console.log('in guards ',permService.totalCount());
    return true;
  }

  return router.createUrlTree(['']);
};
